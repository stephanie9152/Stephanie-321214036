import json
import sqlite3
from flask import Flask
from flask import render_template
from flask import jsonify, redirect
from flask import request

app = Flask(__name__)

con = sqlite3.connect('contatos_db.db', check_same_thread=False)

from datetime import date

@app.route('/')
def index():
    return redirect('/contatos', code=302)


@app.route("/contatos-agrupados", methods=["GET"])
def listarEstadosAgrupados():
    cursor = con.cursor()
    comando_sql = "SELECT nome, GROUP_CONCAT(empresa, ',') FROM Contatos GROUP BY nome"
    cursor.execute(comando_sql)
    dados = cursor.fetchall()
    return jsonify(dados)

@app.route("/contatos", methods=["GET"])
def listarEstados():
    cursor = con.cursor()
    comando_sql = "SELECT * FROM Contatos"
    cursor.execute(comando_sql)
    dados = cursor.fetchall()
    return jsonify(dados)

@app.route("/contatos", methods=["POST"])
def inserirEstado():
    try:
        cursor = con.cursor()
        comando_sql = "INSERT INTO Contatos (nome, empresa, telefone, email) values ('"+request.get_json().get('nome')+"', '"+request.get_json().get('empresa')+"', '"+request.get_json().get('telefone')+"', '"+ request.get_json().get('email')+"')"
        cursor.execute(comando_sql)
        con.commit()
        return jsonify("Sucesso!"), 200
    except sqlite3.OperationalError:
        return jsonify("Erro de execução de query!"), 404


@app.route("/contatos/<int:id>", methods=["PUT"])
def atualizarEstado(id):
    try:
        cursor = con.cursor()
        comando_sql = f"UPDATE Contatos SET nome = '"+request.get_json().get('nome')+"', empresa = '"+request.get_json().get('empresa')+"', telefone = '"+request.get_json().get('telefone')+"', email = '"+ request.get_json().get('email')+"' WHERE id = "+ str(id) +""
        cursor.execute(comando_sql)
        con.commit()
        return jsonify("Sucesso!"), 200
    except sqlite3.OperationalError:
        return jsonify("Erro de execução de query!"), 404

@app.route("/contatos/<int:id>", methods=["DELETE"])
def deletarEstado(id):
    try:
        cursor = con.cursor()
        comando_sql = f"DELETE FROM Contatos WHERE id = " + str(id) + ""
        cursor.execute(comando_sql)
        con.commit()
        return jsonify("Sucesso!"), 200
    except sqlite3.OperationalError:
        return jsonify("Erro de execução de query!"), 404


if __name__ == '__main__':
     app.run(host='0.0.0.0', port=5000)